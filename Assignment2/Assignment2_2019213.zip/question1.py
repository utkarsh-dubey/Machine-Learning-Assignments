#!/usr/bin/env python
# coding: utf-8

# In[39]:


import numpy as np
import matplotlib.pyplot as plt
from math import *
import pandas as pd
import random
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import AdaBoostClassifier
from sklearn.metrics import confusion_matrix,f1_score,accuracy_score,precision_score,recall_score
from sklearn.linear_model import Ridge, Lasso
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import cross_val_score 
np.set_printoptions(suppress=True)
import warnings
warnings.filterwarnings('ignore')


# In[2]:


#function to load the data and randomise it and normalise it further
def loadData():
    df = pd.read_csv('dataset.csv', sep=",", index_col=False)
    df = df.sample(frac=1).reset_index(drop=True)
    df=df[~np.isnan(df['pm2.5'])]
    data=np.array(df)
#     data=np.array(data,dtype=float)
#     normalise(data)
    x=np.concatenate((np.reshape(data[:,1],(-1,1)),data[:,3:]), axis=1)
    y=np.reshape(data[:,2],(-1,1))
    print(x.shape)
    print(y.shape)
    return x,y


# In[3]:


#to normalise data, gets big data into range
def normalise(data):
    data = (data - np.mean(data,axis=0))/np.std(data, axis=0)
    return data


# In[4]:


#encoding cbwd and adding columns for {'cv', 'SE', 'NE', 'NW'}
def handleCBWD(x):
    SE=np.zeros((x.shape[0],1))
    NE=np.zeros((x.shape[0],1))
    NW=np.zeros((x.shape[0],1))
    cv=np.zeros((x.shape[0],1))
    for i in range(x.shape[0]):
        if(x[i][7]=='SE'):
            SE[i]=1
        elif(x[i][7]=='NE'):
            NE[i]=1
        elif(x[i][7]=='NW'):
            NW[i]=1
        elif(x[i][7]=='cv'):
            cv[i]=1
    
    x=np.concatenate((x[:,:7],x[:,8:],SE,NE,NW,cv),axis=1)
#     print(x.shape)
#     print(x)
    return x


# In[5]:


#function to split dataset as required
def train_val_test_split(x,y):
    trainX=[]
    testX=[]
    trainY=[]
    testY=[]
    valX=[]
    valY=[]
    #we have train:val:test = 7:1.5:1.5
    trainFreq=int((7/10)*x.shape[0])
    valFreq=int((1.5/10)*x.shape[0])
    for i in range(trainFreq):
        trainX.append(x[i])
        trainY.append(y[i])
    for i in range(trainFreq,trainFreq+valFreq):
        valX.append(x[i])
        valY.append(y[i])
    for i in range(trainFreq+valFreq,x.shape[0]):
        testX.append(x[i])
        testY.append(y[i])
    
    return np.array(trainX),np.array(trainY),np.array(valX),np.array(valY),np.array(testX),np.array(testY)


# In[6]:


x,y=loadData()
#we have 4 unique entries for cbwd, those are - {'cv', 'SE', 'NE', 'NW'}
x=handleCBWD(x)
x=x.astype(float)
y=y.astype(float)
#splitting dataset for train, val and test
trainingX,trainingY,validatingX,validatingY,testingX,testingY = train_val_test_split(x,y)


# In[7]:


#training and testing classifier with gini
clfgini = DecisionTreeClassifier(criterion="gini")      
clfgini = clfgini.fit(trainingX,trainingY)
print("Accuracy score for gini ",clfgini.score(testingX,testingY))


# In[8]:


#training and testing classifier with entropy
clfentropy = DecisionTreeClassifier(criterion="entropy")      
clfentropy = clfentropy.fit(trainingX,trainingY)
print("Accuracy score for entropy ",clfentropy.score(testingX,testingY))


# In[42]:


#trying out different depths
depth=[2,4,8,10,15,30]
testingAcc=[]
trainingAcc=[]

for i in depth:
    clf = DecisionTreeClassifier(criterion='entropy',max_depth=i)
    clf = clf.fit(trainingX,trainingY)
    testAcc = clf.score(testingX,testingY)
    trainAcc = clf.score(trainingX,trainingY)
    print("Accuracy for depth =",i)
    print("Testing accuracy ", testAcc)
    print("Training accuracy ", trainAcc)
    print()
    print()
    testingAcc.append(testAcc*100)
    trainingAcc.append(trainAcc*100)

plt.plot(depth,testingAcc,'-o',depth,trainingAcc,'-o')
plt.xlabel("Depth")
plt.ylabel("Accuracy")
plt.legend(['testing accuracy', 'training accuracy'])
plt.show()
    
    


# In[21]:


#getting 50% of the dataset randomly
def get50Randon(x,y):
#     print(x.shape[0])
    randomNums=random.sample(range(x.shape[0]),x.shape[0]//2)
    xNew=[]
    yNew=[]
    for  i in randomNums:
        xNew.append(x[i])
        yNew.append(y[i])
    return np.array(xNew,dtype=float),np.array(yNew,dtype=float)
    


# In[33]:


# creating 100 decision trees
forest=[]
for  i in range(100):
    forest.append(DecisionTreeClassifier(criterion='entropy', max_depth=3))

#training all 100 trees with different random 50% out of training set
for i in range(100):
    xTrain,yTrain=get50Randon(trainingX,trainingY)
    forest[i]=forest[i].fit(xTrain,yTrain)

# #predicting on the test set
predictions=[]
for i in range(testingX.shape[0]):
    predictions.append({})

for i in forest:
    yPred=i.predict(testingX)
    for j in range(yPred.shape[0]):
        if(yPred[j] not in predictions[j]):
            predictions[j][yPred[j]]=1
        else:
            predictions[j][yPred[j]]+=1
# print(predictions)
finalPredictions=np.array([max(i, key=i.get) for i in predictions]).reshape((-1,1))

#calculating accuracy
accuracy=(finalPredictions==testingY).mean()
print("Accuracy using 100 trees with max_depth=3",accuracy)


# In[43]:


depths=[4,8,10,15,20]

for depth in depths:
    treeNo=range(20,150,20)
    testingAcc=[]
    trainingAcc=[]
    validatingAcc=[]
    for no in treeNo:
        # creating no decision trees of max_depth depth
        forest=[]
        for  i in range(no):
            forest.append(DecisionTreeClassifier(criterion='entropy', max_depth=depth))

        #training all trees with different random 50% out of training set
        for i in range(no):
            xTrain,yTrain=get50Randon(trainingX,trainingY)
            forest[i]=forest[i].fit(xTrain,yTrain)

        #predicting on the test set
        predictions=[]
        for i in range(testingX.shape[0]):
            predictions.append({})

        for i in forest:
            yPred=i.predict(testingX)
            for j in range(yPred.shape[0]):
                if(yPred[j] not in predictions[j]):
                    predictions[j][yPred[j]]=1
                else:
                    predictions[j][yPred[j]]+=1
        # print(predictions)
        finalPredictions=np.array([max(i, key=i.get) for i in predictions]).reshape((-1,1))

        #calculating accuracy
        accuracy=(finalPredictions==testingY).mean()
        testingAcc.append(accuracy)
#         print("Accuracy using 100 trees with max_depth=3",accuracy)
    
        #predicting on the val set
        predictions=[]
        for i in range(validatingX.shape[0]):
            predictions.append({})

        for i in forest:
            yPred=i.predict(validatingX)
            for j in range(yPred.shape[0]):
                if(yPred[j] not in predictions[j]):
                    predictions[j][yPred[j]]=1
                else:
                    predictions[j][yPred[j]]+=1
        # print(predictions)
        finalPredictions=np.array([max(i, key=i.get) for i in predictions]).reshape((-1,1))

        #calculating accuracy
        accuracy=(finalPredictions==validatingY).mean()
        validatingAcc.append(accuracy)
        
        #predicting on the train set
        predictions=[]
        for i in range(trainingX.shape[0]):
            predictions.append({})

        for i in forest:
            yPred=i.predict(trainingX)
            for j in range(yPred.shape[0]):
                if(yPred[j] not in predictions[j]):
                    predictions[j][yPred[j]]=1
                else:
                    predictions[j][yPred[j]]+=1
        # print(predictions)
        finalPredictions=np.array([max(i, key=i.get) for i in predictions]).reshape((-1,1))

        #calculating accuracy
        accuracy=(finalPredictions==trainingY).mean()
        trainingAcc.append(accuracy)
        
    print("Below is the graph for max depth of ",depth)
    plt.plot(treeNo,testingAcc,treeNo,trainingAcc,treeNo,validatingAcc)
    plt.xlabel("No of trees")
    plt.ylabel("Accuracy")
    plt.legend(['testing accuracy', 'training accuracy','validation accuracy'])
    plt.show()
    print("-----------------------------------------------\n\n")
    
    
    


# In[41]:


estimators = [4, 8, 10, 15, 20]
testingAcc=[]
trainingAcc=[]
validatingAcc=[]

for i in estimators:
    clf = AdaBoostClassifier(n_estimators=i, base_estimator=DecisionTreeClassifier(criterion="entropy", max_depth=i))
    clf.fit(trainingX,trainingY)
    testingAcc.append(clf.score(testingX,testingY))
    trainingAcc.append(clf.score(trainingX,trainingY))
    validatingAcc.append(clf.score(validatingX,validatingY))
    print("Accuracy for estimate =",i)
    print("Testing accuracy ", testingAcc[-1])
    print("Training accuracy ", trainingAcc[-1])
    print("Validating accuracy ", validatingAcc[-1])
    print("---------------------------------------")


plt.plot(estimators,testingAcc,'-o',estimators,trainingAcc,'-o',estimators,validatingAcc,'-o')
plt.xlabel("Estimators")
plt.ylabel("Accuracy")
plt.legend(['testing accuracy', 'training accuracy','validation accuracy'])
plt.show()
print("-----------------------------------------------\n\n")
    

    


# In[ ]:




